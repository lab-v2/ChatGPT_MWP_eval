# Causality calculator
MAWPS, Math23K (it's in chinese tho), ALG 514
### Input
input/data.json -- Data is expected to 

### How to use it
In the .env file, modify the values as instructed
To use it, just run "run.py" and it will generate all the required files for each possible source file in src/config

### Some things you can modify
In src/configs, there are python files which define how the [CORRECT_COLUMN] and [VALID_COLUMN] columns are labelled.
You can create your own files which define how a row is correct and run.py will generate the corresponding output files with their causality values.

### Python version
3.7.9

### pip Versions
pandas              -- 1.3.5 
numpy               -- 1.21.6 
scikit-learn        -- 1.0.2
python-dotenv       -- 0.21.1
matplotlib          -- 3.5.3
torch               -- 1.13.1+cu116
torchaudio          -- 0.13.1+cu116
torchvision         -- 0.14.1+cu116

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
OfficialChatGPT --api_key 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 --stream